import React, { useState, useEffect } from 'react';
import { Order, ProductItem } from '../types';
import { X, MapPin, Phone, CreditCard, Banknote, CheckCircle, XCircle, FileText, Calendar, Smartphone, Download, Eye, ZoomIn, ZoomOut, RotateCcw, Image as ImageIcon, Package, Check, Camera } from 'lucide-react';
import { useLanguage } from '../i18n';

interface OrderDetailsModalProps {
  order: Order;
  onClose: () => void;
  onUpdate?: (updatedOrder: Order) => Promise<void>;
  userRole?: string;
}

export default function OrderDetailsModal({ order, onClose, onUpdate, userRole }: OrderDetailsModalProps) {
  const { t, language } = useLanguage();
  const [selectedFile, setSelectedFile] = useState<{name: string, dataUrl: string} | null>(null);
  const [zoom, setZoom] = useState(1);
  const [localOrder, setLocalOrder] = useState<Order>(order);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    setLocalOrder(order);
  }, [order]);

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.25, 3));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.25, 0.5));
  const handleResetZoom = () => setZoom(1);

  const handleStockStatusChange = async (idx: number, isAvailable: boolean) => {
    if (userRole !== 'stock_keeper' && userRole !== 'admin') return;
    
    const newProductDetails = [...localOrder.productDetails];
    newProductDetails[idx] = { ...newProductDetails[idx], isAvailable };
    
    // Check if all products are available
    const allAvailable = newProductDetails.every(item => item.isAvailable === true);
    
    const updatedOrder = { 
      ...localOrder, 
      productDetails: newProductDetails,
      isReady: allAvailable
    };
    
    setLocalOrder(updatedOrder);
    if (onUpdate) {
      setIsUpdating(true);
      await onUpdate(updatedOrder);
      setIsUpdating(false);
    }
  };

  const handlePaymentConfirmationUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const base64 = ev.target?.result as string;
      const updatedOrder = { ...localOrder, paymentConfirmationImage: base64 };
      setLocalOrder(updatedOrder);
      if (onUpdate) {
        setIsUpdating(true);
        await onUpdate(updatedOrder);
        setIsUpdating(false);
      }
    };
    reader.readAsDataURL(file);
  };

  useEffect(() => {
    if (!selectedFile) setZoom(1);
  }, [selectedFile]);

  return (
    <div className="fixed inset-0 bg-amarous-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-amarous-bg">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amarous-teal/10 text-amarous-teal rounded-xl flex items-center justify-center font-bold text-xl">
              #{order.orderNumber}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold text-slate-800">{order.customerName}</h3>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${order.type === 'social' ? 'bg-indigo-100 text-indigo-700' : 'bg-amarous-teal/10 text-amarous-teal'}`}>
                  {order.type === 'social' ? t('social') : t('website')}
                </span>
              </div>
              <p className="text-sm text-slate-500 flex items-center gap-1 mt-1">
                <Calendar size={14} />
                {new Date(order.createdAt).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors bg-white p-2 rounded-lg shadow-sm">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          {/* Status Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className={`p-4 rounded-xl border ${order.isPaid ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-rose-50 border-rose-100 text-rose-700'}`}>
              <div className="flex items-center gap-2 mb-2">
                {order.isPaid ? <CheckCircle size={18} /> : <XCircle size={18} />}
                <span className="font-semibold text-sm">{t('paymentStatus')}</span>
              </div>
              <p className="font-bold">{order.isPaid ? t('paid') : t('unpaid')}</p>
            </div>

            <div className={`p-4 rounded-xl border ${order.isReady ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-rose-50 border-rose-100 text-rose-700'}`}>
              <div className="flex items-center gap-2 mb-2">
                {order.isReady ? <CheckCircle size={18} /> : <XCircle size={18} />}
                <span className="font-semibold text-sm">{t('status')}</span>
              </div>
              <p className="font-bold">{order.isReady ? t('ready') : t('notReady')}</p>
            </div>
            
            <div className="p-4 rounded-xl border bg-amarous-bg border-slate-100 text-slate-700">
              <div className="flex items-center gap-2 mb-2 text-slate-500">
                {order.paymentMethod === 'Visa' ? <CreditCard size={18} /> : order.paymentMethod === 'InstaPay' ? <Smartphone size={18} /> : <Banknote size={18} />}
                <span className="font-semibold text-sm">{t('paymentMethod')}</span>
              </div>
              <p className="font-bold">{order.paymentMethod === 'Visa' ? t('visa') : order.paymentMethod === 'InstaPay' ? t('instapay') : t('cash')}</p>
            </div>

            <div className={`p-4 rounded-xl border ${order.isContacted ? 'bg-amarous-teal/10 border-amarous-teal/20 text-amarous-teal-dark' : 'bg-amarous-bg border-slate-100 text-slate-600'}`}>
              <div className="flex items-center gap-2 mb-2">
                <Phone size={18} />
                <span className="font-semibold text-sm">{t('contact')}</span>
              </div>
              <p className="font-bold">{order.isContacted ? t('contacted') : t('notContacted')}</p>
            </div>
          </div>

          {/* Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">{t('customerInfo')}</h4>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="mt-1 text-amarous-teal"><Phone size={18} /></div>
                  <div>
                    <p className="text-sm text-slate-500 mb-0.5">{t('customerPhone')}</p>
                    <p className="font-medium text-slate-800" dir="ltr">{order.customerPhone || t('notAvailable')}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 text-amarous-teal"><MapPin size={18} /></div>
                  <div>
                    <p className="text-sm text-slate-500 mb-0.5">{t('location')}</p>
                    <p className="font-medium text-slate-800 leading-relaxed">{order.deliveryLocation || t('notAvailable')}</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">{t('invoiceNotes')}</h4>
              <div className="bg-amarous-yellow/10 border border-amarous-yellow/20 rounded-xl p-4 min-h-[100px]">
                {order.notes ? (
                  <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">{order.notes}</p>
                ) : (
                  <p className="text-slate-400 italic">{t('noNotes')}</p>
                )}
              </div>
            </div>

            {/* Stock Approval Section */}
            {(userRole === 'stock_keeper' || userRole === 'admin') && (
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">{t('stockApproval')}</h4>
                  {isUpdating && <span className="text-[10px] text-amarous-teal animate-pulse font-bold uppercase">{t('saving...')}</span>}
                </div>
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                  <table className="w-full text-sm">
                    <thead className="bg-amarous-bg text-slate-500 font-semibold border-b border-slate-200">
                      <tr>
                        <th className={`px-4 py-3 ${language === 'ar' ? 'text-right' : 'text-left'}`}>{t('productName')}</th>
                        <th className="px-4 py-3 text-center">{t('quantity')}</th>
                        <th className="px-4 py-3 text-center">{t('actions')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {localOrder.productDetails.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                          <td className={`px-4 py-3 text-slate-700 font-medium ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                            <div className="flex items-center gap-3">
                              {item.thumbnail && (
                                <img src={item.thumbnail} alt={item.name} className="w-8 h-8 rounded object-cover border border-slate-200" />
                              )}
                              <span>{item.name}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-center font-bold text-slate-600">
                            {item.quantity || 1}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center justify-center gap-2">
                              <button 
                                disabled={(userRole !== 'stock_keeper' && userRole !== 'admin') || isUpdating}
                                onClick={() => handleStockStatusChange(idx, true)}
                                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                  item.isAvailable === true 
                                    ? 'bg-emerald-500 text-white shadow-md shadow-emerald-200' 
                                    : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                                } disabled:opacity-50 disabled:cursor-not-allowed`}
                              >
                                <Check size={14} />
                                {t('available')}
                              </button>
                              <button 
                                disabled={(userRole !== 'stock_keeper' && userRole !== 'admin') || isUpdating}
                                onClick={() => handleStockStatusChange(idx, false)}
                                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                  item.isAvailable === false 
                                    ? 'bg-rose-500 text-white shadow-md shadow-rose-200' 
                                    : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                                } disabled:opacity-50 disabled:cursor-not-allowed`}
                              >
                                <X size={14} />
                                {t('notAvailable')}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Product Details Section */}
            <div className="md:col-span-2">
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">{t('productDetails')}</h4>
              <div className="bg-amarous-bg rounded-2xl border border-slate-200 overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-slate-100/50 text-slate-500 font-semibold border-b border-slate-200">
                    <tr>
                      <th className={`px-4 py-3 ${language === 'ar' ? 'text-right' : 'text-left'}`}>{t('productName')}</th>
                      <th className="px-4 py-3 text-center">{t('quantity')}</th>
                      <th className={`px-4 py-3 ${language === 'ar' ? 'text-left' : 'text-right'}`}>{t('price')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {Array.isArray(order.productDetails) && order.productDetails.length > 0 ? (
                      order.productDetails.map((item, idx) => (
                        <tr key={idx}>
                          <td className={`px-4 py-3 text-slate-700 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                            <div className="flex items-center gap-3">
                              {item.thumbnail && (
                                <img src={item.thumbnail} alt={item.name} className="w-8 h-8 rounded object-cover border border-slate-200" />
                              )}
                              <span>{item.name}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-center font-bold text-slate-600">
                            {item.quantity || 1}
                          </td>
                          <td className={`px-4 py-3 font-medium text-slate-800 ${language === 'ar' ? 'text-left' : 'text-right'}`}>{item.price} EGP</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={2} className="px-4 py-8 text-center text-slate-400 italic">
                          {t('noProducts')}
                        </td>
                      </tr>
                    )}
                  </tbody>
                  <tfoot className="bg-slate-100/30 font-bold text-slate-800 border-t border-slate-200">
                    {!order.isPaid && (
                      <tr className="bg-rose-50/50">
                        <td colSpan={2} className="px-4 py-2 text-rose-600 text-center text-xs uppercase tracking-widest">
                          {t('paymentPending')}
                        </td>
                      </tr>
                    )}
                    <tr>
                      <td className={`px-4 py-2 text-slate-500 font-medium ${language === 'ar' ? 'text-right' : 'text-left'}`}>{t('subtotal')}</td>
                      <td className={`px-4 py-2 ${language === 'ar' ? 'text-left' : 'text-right'}`}>{order.total - order.shippingCost} EGP</td>
                    </tr>
                    <tr>
                      <td className={`px-4 py-2 text-slate-500 font-medium ${language === 'ar' ? 'text-right' : 'text-left'}`}>{t('shipping')}</td>
                      <td className={`px-4 py-2 ${language === 'ar' ? 'text-left' : 'text-right'}`}>{order.shippingCost} EGP</td>
                    </tr>
                    {order.discount !== undefined && order.discount > 0 && (
                      <tr>
                        <td className={`px-4 py-2 text-rose-600 font-medium ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                          {t('discount')}
                          {order.discountType === 'percentage' ? ` (${order.discount}%)` : ''}
                        </td>
                        <td className={`px-4 py-2 text-rose-600 ${language === 'ar' ? 'text-left' : 'text-right'}`}>
                          -
                          {order.discountType === 'percentage' 
                            ? ((order.productDetails.reduce((sum, item) => sum + (Number(item.price) || 0), 0) * order.discount) / 100).toFixed(2)
                            : order.discount
                          } EGP
                        </td>
                      </tr>
                    )}
                    <tr className="bg-slate-200/50">
                      <td className={`px-4 py-4 text-slate-900 ${language === 'ar' ? 'text-right' : 'text-left'}`}>{t('total')}</td>
                      <td className={`px-4 py-4 text-slate-900 ${language === 'ar' ? 'text-left' : 'text-right'}`}>{order.total} EGP</td>
                    </tr>
                    <tr>
                      <td className={`px-4 py-2 text-emerald-600 font-medium ${language === 'ar' ? 'text-right' : 'text-left'}`}>{t('paidAmount')}</td>
                      <td className={`px-4 py-2 text-emerald-600 ${language === 'ar' ? 'text-left' : 'text-right'}`}>{order.paidAmount} EGP</td>
                    </tr>
                    <tr className="text-lg bg-rose-50 border-t-2 border-rose-200">
                      <td className={`px-4 py-4 text-slate-900 ${language === 'ar' ? 'text-right' : 'text-left'}`}>{t('balance')}</td>
                      <td className={`px-4 py-4 text-rose-600 font-bold ${language === 'ar' ? 'text-left' : 'text-right'}`}>{order.total - order.paidAmount} EGP</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>

          {/* Attached PDFs */}
          {((Array.isArray(order.pdfFiles) && order.pdfFiles.length > 0) || !!order.thumbnail || !!order.paymentConfirmationImage) && (
            <div>
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">{t('attachedFiles')}</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {order.paymentConfirmationImage && (
                  <div className="flex items-center justify-between p-3 bg-emerald-50 border border-emerald-100 rounded-xl hover:border-emerald-500 transition-colors group">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="bg-white p-2 rounded-lg shadow-sm text-emerald-500 group-hover:text-emerald-600 transition-colors">
                        <CheckCircle size={20} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-emerald-700 truncate">{t('confirmPayment')}</p>
                      </div>
                    </div>
                    <div className={`flex items-center gap-1 ${language === 'en' ? 'ml-2' : 'mr-2'}`}>
                      <button 
                        onClick={() => setSelectedFile({ name: t('confirmPayment'), dataUrl: order.paymentConfirmationImage! })}
                        className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-emerald-600 bg-white border border-emerald-200 hover:bg-emerald-100 rounded-lg transition-colors"
                      >
                        <Eye size={14} />
                        {t('view')}
                      </button>
                    </div>
                  </div>
                )}
                {order.thumbnail && (
                  <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl hover:border-amarous-teal transition-colors group">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="bg-white p-2 rounded-lg shadow-sm text-slate-400 group-hover:text-amarous-teal transition-colors">
                        <ImageIcon size={20} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-700 truncate">{t('invoiceImage')}</p>
                      </div>
                    </div>
                    <div className={`flex items-center gap-1 ${language === 'en' ? 'ml-2' : 'mr-2'}`}>
                      <button 
                        onClick={() => setSelectedFile({ name: t('invoiceImage'), dataUrl: order.thumbnail! })}
                        className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-amarous-teal bg-amarous-teal/10 hover:bg-amarous-teal/20 rounded-lg transition-colors"
                      >
                        <Eye size={14} />
                        {t('view')}
                      </button>
                      <a 
                        href={order.thumbnail}
                        download={`invoice-${order.orderNumber}.jpg`}
                        className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-200 hover:bg-slate-300 rounded-lg transition-colors"
                      >
                        <Download size={14} />
                        {t('download')}
                      </a>
                    </div>
                  </div>
                )}
                {Array.isArray(order.pdfFiles) && order.pdfFiles.map((pdf, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl hover:border-amarous-teal transition-colors group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="bg-white p-2 rounded-lg shadow-sm text-slate-400 group-hover:text-amarous-teal transition-colors">
                        <FileText size={20} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-700 truncate">{pdf.name}</p>
                      </div>
                    </div>
                    <div className={`flex items-center gap-1 ${language === 'en' ? 'ml-2' : 'mr-2'}`}>
                      <button 
                        onClick={() => setSelectedFile(pdf)}
                        className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-amarous-teal bg-amarous-teal/10 hover:bg-amarous-teal/20 rounded-lg transition-colors"
                      >
                        <Eye size={14} />
                        {t('view')}
                      </button>
                      <a 
                        href={pdf.dataUrl}
                        download={pdf.name}
                        className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-200 hover:bg-slate-300 rounded-lg transition-colors"
                      >
                        <Download size={14} />
                        {t('download')}
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* File Viewer Modal */}
      {selectedFile && (
        <div className="fixed inset-0 bg-amarous-black/60 backdrop-blur-sm flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-5xl h-[90vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-amarous-bg">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <FileText size={20} className="text-amarous-teal" />
                {selectedFile.name}
              </h3>
              <div className="flex items-center gap-2">
                {selectedFile.dataUrl.startsWith('data:image/') && (
                  <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1 mr-4">
                    <button 
                      onClick={handleZoomOut}
                      className="p-1.5 hover:bg-slate-100 rounded text-slate-600 transition-colors"
                      title="Zoom Out"
                    >
                      <ZoomOut size={18} />
                    </button>
                    <span className="text-xs font-bold text-slate-500 w-12 text-center">
                      {Math.round(zoom * 100)}%
                    </span>
                    <button 
                      onClick={handleZoomIn}
                      className="p-1.5 hover:bg-slate-100 rounded text-slate-600 transition-colors"
                      title="Zoom In"
                    >
                      <ZoomIn size={18} />
                    </button>
                    <button 
                      onClick={handleResetZoom}
                      className="p-1.5 hover:bg-slate-100 rounded text-slate-600 transition-colors border-l border-slate-100 ml-1"
                      title="Reset Zoom"
                    >
                      <RotateCcw size={16} />
                    </button>
                  </div>
                )}
                <a 
                  href={selectedFile.dataUrl}
                  download={selectedFile.name}
                  className="flex items-center gap-2 px-4 py-2 bg-amarous-teal hover:bg-amarous-teal-dark text-white rounded-lg font-medium transition-colors text-sm"
                >
                  <Download size={16} />
                  {t('download')}
                </a>
                <button onClick={() => setSelectedFile(null)} className="text-slate-400 hover:text-slate-600 transition-colors bg-slate-100 p-2 rounded-lg">
                  <X size={20} />
                </button>
              </div>
            </div>
            <div className="flex-1 w-full bg-slate-200 flex items-center justify-center overflow-auto p-8">
              {selectedFile.dataUrl.startsWith('data:image/') ? (
                <div className="relative transition-transform duration-200 ease-out" style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}>
                  <img 
                    src={selectedFile.dataUrl} 
                    alt={selectedFile.name} 
                    className="max-w-none shadow-2xl rounded-sm" 
                    style={{ maxHeight: '80vh' }}
                  />
                </div>
              ) : (
                <iframe src={selectedFile.dataUrl} className="w-full h-full border-none bg-white" title={selectedFile.name} />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
