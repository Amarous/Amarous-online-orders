import React, { useState, useRef, useEffect } from 'react';
import { Order } from '../types';
import { X, UploadCloud, Loader2, File as FileIcon, Trash2, Image as ImageIcon, Plus, Camera, Download, ChevronUp, ChevronDown } from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { EXTRACTION_SCHEMA } from '../constants';
import { useLanguage } from '../i18n';
import * as pdfjsLib from 'pdfjs-dist';

// Set worker source for pdfjs
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`;

interface OrderModalProps {
  order: Order | null;
  type?: 'website' | 'social';
  orders?: Order[];
  onClose: () => void;
  onSave: (order: Order) => void;
  onBatchUpload?: (files: FileList) => void;
  userRole?: string;
}

export default function OrderModal({ order, onClose, onSave, onBatchUpload, type = 'website', userRole, orders = [] }: OrderModalProps) {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState<Partial<Order>>(
    order || {
      orderNumber: '',
      customerName: '',
      customerPhone: '',
      deliveryLocation: '',
      isPaid: false,
      paymentMethod: 'Cash',
      isContacted: false,
      notes: '',
      pdfFiles: [],
      type: type
    }
  );
  const [isExtracting, setIsExtracting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const retry = async <T,>(fn: () => Promise<T>, maxRetries = 7, delay = 5000): Promise<T> => {
    let lastError: any;
    for (let i = 0; i < maxRetries; i++) {
      try {
        return await fn();
      } catch (error: any) {
        lastError = error;
        const errorStr = JSON.stringify(error).toLowerCase();
        const errorMsg = (error?.message || '').toLowerCase();
        
        if (
          errorMsg.includes('429') || 
          errorMsg.includes('resource_exhausted') || 
          errorMsg.includes('quota') ||
          errorStr.includes('429') ||
          errorStr.includes('resource_exhausted') ||
          errorStr.includes('quota')
        ) {
          const waitTime = delay + Math.random() * 2000; // Add jitter
          console.log(`Rate limit hit, retrying in ${Math.round(waitTime)}ms... (Attempt ${i + 1}/${maxRetries})`);
          await new Promise(resolve => setTimeout(resolve, waitTime));
          delay *= 2; // Exponential backoff
          continue;
        }
        throw error;
      }
    }
    throw lastError;
  };

  const cropProductImage = async (base64: string, box: number[]): Promise<string> => {
    if (!box || box.length !== 4) return '';
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve('');
          return;
        }

        // box is [ymin, xmin, ymax, xmax] in 0-1000
        const ymin = (box[0] / 1000) * img.height;
        const xmin = (box[1] / 1000) * img.width;
        const ymax = (box[2] / 1000) * img.height;
        const xmax = (box[3] / 1000) * img.width;

        const width = Math.max(1, xmax - xmin);
        const height = Math.max(1, ymax - ymin);

        canvas.width = width;
        canvas.height = height;

        ctx.drawImage(img, xmin, ymin, width, height, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => resolve('');
      img.src = base64;
    });
  };

  // Automatic total calculation
  useEffect(() => {
    const details = Array.isArray(formData.productDetails) ? formData.productDetails : [];
    const subtotal = details.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
    const shipping = Number(formData.shippingCost) || 0;
    const discountVal = Number(formData.discount) || 0;
    
    let discountAmount = discountVal;
    if (formData.discountType === 'percentage') {
      discountAmount = (subtotal * discountVal) / 100;
    }
    
    const newTotal = subtotal + shipping - discountAmount;
    
    // Only update if the total has actually changed to avoid infinite loops
    if (Math.abs(newTotal - (formData.total || 0)) > 0.01) {
      setFormData(prev => ({ ...prev, total: Math.max(0, newTotal) }));
    }
  }, [formData.productDetails, formData.shippingCost, formData.discount, formData.discountType, formData.total]);

  // Unified invoice numbering sequence
  useEffect(() => {
    if (!order?.id && !formData.orderNumber && orders.length > 0) {
      const allNumbers = orders.map(o => {
        const numStr = (o.orderNumber || '').replace(/#S-|#W-|#INV-/, '');
        const num = parseInt(numStr);
        return isNaN(num) ? 0 : num;
      });
      const nextNum = Math.max(0, ...allNumbers) + 1;
      const prefix = type === 'social' ? '#S-' : '#W-';
      setFormData(prev => ({ ...prev, orderNumber: `${prefix}${nextNum}` }));
    }
  }, [order, orders, type, formData.orderNumber]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData(prev => {
      let newData = { ...prev, [name]: type === 'checkbox' ? checked : value };
      
      // Automatic isPaid logic based on paidAmount and total
      if (name === 'paidAmount' || name === 'total') {
        const total = name === 'total' ? Number(value) : Number(prev.total);
        const paidAmount = name === 'paidAmount' ? Number(value) : Number(prev.paidAmount);
        newData.isPaid = paidAmount >= total;
      }
      
      // If payment status is toggled manually, update paidAmount
      if (name === 'isPaid') {
        if (checked) {
          newData.paidAmount = prev.total || 0;
        } else {
          newData.paidAmount = 0;
        }
      }
      
      return newData;
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // If multiple files are selected and we are in "Add" mode, trigger batch upload
    if (files.length > 1 && !order?.id && onBatchUpload) {
      onBatchUpload(files);
      onClose();
      return;
    }

    const file = files[0];
    const isSocial = type === 'social';
    
    if (isSocial) {
      if (!file.type.startsWith('image/')) {
        alert(t('imageError'));
        return;
      }
    } else {
      if (file.type !== 'application/pdf' && !file.type.startsWith('image/')) {
        alert(t('pdfOrImageError'));
        return;
      }
    }

    setIsExtracting(true);
    try {
      // 1. Read file as base64 for storage and API
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
      });

      let thumbnail = '';
      if (file.type === 'application/pdf') {
        try {
          const arrayBuffer = await file.arrayBuffer();
          const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
          const page = await pdf.getPage(1);
          const viewport = page.getViewport({ scale: 1.0 });
          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          if (context) {
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            await page.render({ canvasContext: context, viewport, canvas } as any).promise;
            thumbnail = canvas.toDataURL('image/jpeg', 0.7);
          }
        } catch (pdfErr) {
          console.error('Error generating PDF thumbnail:', pdfErr);
        }
      } else if (file.type.startsWith('image/')) {
        thumbnail = base64;
      }

      // Add file to formData
      setFormData(prev => ({
        ...prev,
        pdfFiles: [...(prev.pdfFiles || []), { name: file.name, dataUrl: base64, mimeType: file.type }],
        thumbnail: thumbnail || prev.thumbnail
      }));

      // 2. Extract data using Gemini
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const base64Data = base64.split(',')[1];

      const response = await retry(() => ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            inlineData: {
              mimeType: file.type,
              data: base64Data
            }
          },
          `Extract the following order details from this ${file.type === 'application/pdf' ? 'PDF document' : 'image'}. If a field is not found, leave it empty or use default values. Return ONLY a JSON object.`
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: EXTRACTION_SCHEMA
        }
      }));

      const text = response.text;
      if (text) {
        // Clean the text in case it's wrapped in markdown
        const jsonStr = text.replace(/```json\n?|```/g, '').trim();
        const extractedData = JSON.parse(jsonStr);
        
        let processedProductDetails = extractedData.productDetails || [];
        if (extractedData.productDetails && thumbnail) {
          processedProductDetails = await Promise.all(extractedData.productDetails.map(async (item: any) => {
            let itemThumbnail = '';
            if (item.imageBox) {
              itemThumbnail = await cropProductImage(thumbnail, item.imageBox);
            }
            
            return {
              ...item,
              unitPrice: item.unitPrice || (item.price / (item.quantity || 1)) || item.price,
              quantity: item.quantity || 1,
              thumbnail: itemThumbnail || undefined
            };
          }));
        } else if (extractedData.productDetails) {
          processedProductDetails = extractedData.productDetails.map((item: any) => ({
            ...item,
            unitPrice: item.unitPrice || (item.price / (item.quantity || 1)) || item.price,
            quantity: item.quantity || 1
          }));
        }

        setFormData(prev => {
          const newData = { ...prev };
          
          if (extractedData.orderNumber && !isSocial) {
            const trimmedNum = extractedData.orderNumber.toString().trim();
            const isDuplicate = orders.some(o => o.orderNumber === trimmedNum && o.id !== order?.id);
            if (isDuplicate) {
              alert(`تنبيه: رقم الفاتورة المستخرج (${trimmedNum}) موجود بالفعل في النظام.`);
            }
            newData.orderNumber = extractedData.orderNumber;
          }
          if (extractedData.customerName) newData.customerName = extractedData.customerName;
          if (extractedData.customerPhone) newData.customerPhone = extractedData.customerPhone;
          if (extractedData.deliveryLocation) newData.deliveryLocation = extractedData.deliveryLocation;
          
          if (extractedData.isPaid !== undefined) {
            newData.isPaid = extractedData.isPaid;
          }
          
          if (extractedData.paymentMethod) {
            const pm = extractedData.paymentMethod.toLowerCase();
            if (pm.includes('visa') || pm.includes('card') || pm.includes('bank')) newData.paymentMethod = 'Visa';
            else if (pm.includes('insta')) newData.paymentMethod = 'InstaPay';
            else if (pm.includes('cash') || pm.includes('نقدي')) newData.paymentMethod = 'Cash';
          }

          if (extractedData.total) newData.total = extractedData.total;
          if (extractedData.shippingCost) newData.shippingCost = extractedData.shippingCost;
          if (extractedData.discount) newData.discount = extractedData.discount;
          if (extractedData.paidAmount) newData.paidAmount = extractedData.paidAmount;
          
          newData.discountType = extractedData.discountType || 'amount';
          newData.productDetails = processedProductDetails;
          
          return newData;
        });
      }

    } catch (error) {
      console.error("Error processing PDF:", error);
      alert(t('pdfExtractError'));
    } finally {
      setIsExtracting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handlePaymentConfirmationUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const base64 = ev.target?.result as string;
      setFormData(prev => ({ ...prev, paymentConfirmationImage: base64 }));
    };
    reader.readAsDataURL(file);
  };

  const removePdf = (index: number) => {
    setFormData(prev => ({
      ...prev,
      pdfFiles: prev.pdfFiles?.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.orderNumber || !formData.customerName) {
      alert(t('requiredFields'));
      return;
    }

    // Check for duplicate order number or file content
    const trimmedNumber = (formData.orderNumber || '').trim();
    const isTemp = !trimmedNumber || trimmedNumber.startsWith('TEMP-');
    
    // 1. Check by order number
    if (!isTemp) {
      const isDuplicate = orders.some(o => (o.orderNumber || '').trim() === trimmedNumber && o.id !== order?.id);
      if (isDuplicate) {
        alert(`يوجد خطأ: رقم الفاتورة ${trimmedNumber} موجود بالفعل في النظام. لا يمكن تكرار رقم الفاتورة.`);
        return;
      }
    }

    // 2. Check by file content (dataUrl)
    if (formData.pdfFiles && formData.pdfFiles.length > 0) {
      const firstFileData = formData.pdfFiles[0].dataUrl;
      const fileExistsInDb = orders.some(o => 
        o.id !== order?.id && (o.pdfFiles || []).some(f => f.dataUrl === firstFileData)
      );
      if (fileExistsInDb) {
        alert('يوجد خطأ: هذا الملف (الفاتورة) موجود بالفعل في النظام. لا يمكن تكرار الفواتير.');
        return;
      }
    }

    // 3. Check by data similarity (Customer + Total) if number is missing and it's a new order
    if (isTemp && !order?.id) {
      const similarOrder = orders.find(o => 
        o.customerName === formData.customerName && 
        Math.abs(o.total - (formData.total || 0)) < 0.01
      );
      if (similarOrder) {
        alert('يوجد خطأ: بيانات هذه الفاتورة (العميل والمبلغ) موجودة بالفعل في النظام. يرجى التأكد من عدم تكرار الفواتير.');
        return;
      }
    }

    setIsSaving(true);
    try {
      const newOrder: Order = {
        id: order?.id || crypto.randomUUID(),
        orderNumber: (formData.orderNumber || '').trim(),
        customerName: (formData.customerName || '').trim(),
        customerPhone: (formData.customerPhone || '').trim(),
        deliveryLocation: formData.deliveryLocation || '',
        isPaid: formData.isPaid || false,
        paymentMethod: formData.paymentMethod as 'Cash' | 'Visa' | 'InstaPay' || 'Cash',
        isContacted: formData.isContacted || false,
        notes: formData.notes || '',
        pdfFiles: formData.pdfFiles || [],
        thumbnail: formData.thumbnail,
        total: Number(formData.total) || 0,
        shippingCost: Number(formData.shippingCost) || 0,
        discount: Number(formData.discount) || 0,
        discountType: formData.discountType || 'amount',
        paidAmount: Number(formData.paidAmount) || 0,
        productDetails: formData.productDetails || [],
        createdAt: order?.createdAt || new Date().toISOString(),
        type: (order?.type || formData.type || type) as 'website' | 'social',
        isReady: formData.isReady || false,
        paymentConfirmationImage: formData.paymentConfirmationImage || null
      };

      await onSave(newOrder);
    } catch (error) {
      console.error("Error saving order:", error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`bg-white rounded-2xl shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden border-t-8 ${
        type === 'social' ? 'border-purple-600' : 'border-amarous-teal'
      }`}>
        <div className="flex items-center justify-between p-6 border-b border-slate-100">
          <h3 className="text-xl font-bold text-slate-800">
            {order?.id ? t('editInvoice') : (type === 'social' ? t('addSocialInvoice') : t('addInvoice'))}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {/* Extraction Section */}
          <div className="mb-8">
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              {type === 'social' ? t('extractImage') : t('extractPdf')}
            </label>
            <div 
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${isExtracting ? 'border-amarous-teal bg-amarous-teal/5' : 'border-slate-200 hover:border-amarous-teal/50 hover:bg-slate-50'}`}
            >
              <input 
                type="file" 
                multiple
                accept={type === 'social' ? "image/*" : ".pdf,image/*"} 
                className="hidden" 
                ref={fileInputRef}
                onChange={handleFileUpload}
                disabled={isExtracting}
              />
              {isExtracting ? (
                <div className="flex flex-col items-center text-amarous-teal">
                  <Loader2 className="animate-spin mb-2" size={32} />
                  <p className="font-medium">{t('extracting')}</p>
                </div>
              ) : (
                <div className="flex flex-col items-center cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                  <div className="w-12 h-12 bg-amarous-teal/10 text-amarous-teal rounded-full flex items-center justify-center mb-3">
                    <UploadCloud size={24} />
                  </div>
                  <p className="font-medium text-slate-700">
                    {type === 'social' ? t('clickToUploadImage') : t('clickToUploadPdf')}
                  </p>
                  <p className="text-sm text-slate-500 mt-1">{t('autoFill')}</p>
                </div>
              )}
            </div>

            {/* Thumbnail Preview */}
            {formData.thumbnail && (
              <div className="mt-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t('invoiceImage')}</p>
                <div className="relative w-32 h-32 rounded-xl overflow-hidden border border-slate-200 bg-slate-50 group">
                  <img src={formData.thumbnail} alt="Preview" className="w-full h-full object-cover" />
                  <button 
                    type="button" 
                    onClick={() => setFormData(prev => ({ ...prev, thumbnail: undefined }))}
                    className="absolute top-1 right-1 p-1 bg-rose-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X size={12} />
                  </button>
                </div>
              </div>
            )}

            {/* Uploaded Files List */}
            {Array.isArray(formData.pdfFiles) && formData.pdfFiles.length > 0 && (
              <div className="mt-4 space-y-2">
                {formData.pdfFiles.map((pdf, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <div className="flex items-center gap-3">
                      {pdf.dataUrl.startsWith('data:image/') ? (
                        <ImageIcon size={18} className="text-amarous-teal" />
                      ) : (
                        <FileIcon size={18} className="text-amarous-teal" />
                      )}
                      <span className="text-sm font-medium text-slate-700 truncate max-w-[200px]">{pdf.name}</span>
                    </div>
                    <button type="button" onClick={() => removePdf(idx)} className="text-rose-500 hover:text-rose-700 p-1">
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <form id="order-form" onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('invoiceNumber')} *</label>
                <input 
                  type="text" 
                  name="orderNumber"
                  required
                  value={formData.orderNumber}
                  onChange={handleChange}
                  className={`w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'en' ? 'text-left' : ''}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('customerName')}</label>
                <input 
                  type="text" 
                  name="customerName"
                  required
                  value={formData.customerName}
                  onChange={handleChange}
                  className={`w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'en' ? 'text-left' : ''}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('shippingCost')} (EGP)</label>
                <input 
                  type="number" 
                  name="shippingCost"
                  value={formData.shippingCost || ''}
                  onChange={handleChange}
                  className={`w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'en' ? 'text-left' : ''}`}
                />
              </div>
              <div className="md:col-span-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">{t('discount')}</label>
                  <div className="flex bg-white border border-slate-200 rounded-lg p-1 shadow-sm">
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, discountType: 'amount' }))}
                      className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                        (formData.discountType || 'amount') === 'amount' 
                          ? 'bg-amarous-teal text-white shadow-sm' 
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      EGP
                    </button>
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, discountType: 'percentage' }))}
                      className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                        formData.discountType === 'percentage' 
                          ? 'bg-amarous-teal text-white shadow-sm' 
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      %
                    </button>
                  </div>
                </div>
                <div className="relative">
                  <input 
                    type="number" 
                    name="discount"
                    value={formData.discount || ''}
                    onChange={handleChange}
                    disabled={userRole !== 'admin'}
                    placeholder={formData.discountType === 'percentage' ? '0%' : '0.00 EGP'}
                    className={`w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'en' ? 'text-left' : ''} disabled:opacity-50 font-bold text-lg`}
                  />
                  <div className={`absolute top-1/2 -translate-y-1/2 ${language === 'ar' ? 'left-4' : 'right-4'} text-slate-300 font-bold`}>
                    {formData.discountType === 'percentage' ? '%' : 'EGP'}
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('total')} (EGP)</label>
                <input 
                  type="number" 
                  readOnly
                  value={formData.total || 0}
                  className={`w-full px-4 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-slate-500 font-bold ${language === 'en' ? 'text-left' : ''}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('paidAmount')} (EGP)</label>
                <input 
                  type="number" 
                  name="paidAmount"
                  value={formData.paidAmount || ''}
                  onChange={handleChange}
                  disabled={userRole !== 'admin'}
                  className={`w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'en' ? 'text-left' : ''} ${(formData.paidAmount || 0) >= (formData.total || 0) ? 'text-emerald-600 font-bold' : ''} disabled:opacity-50`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('balance')} (EGP)</label>
                <input 
                  type="number" 
                  readOnly
                  value={(Number(formData.total) || 0) - (Number(formData.paidAmount) || 0)}
                  className={`w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-rose-600 font-bold ${language === 'en' ? 'text-left' : ''}`}
                />
              </div>
            </div>

            {/* Product Details Section */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                <FileIcon size={18} className="text-amarous-teal" />
                {t('productDetails')}
              </h4>
              <div className="space-y-3">
                {(Array.isArray(formData.productDetails) ? formData.productDetails : []).map((item, idx) => (
                  <div key={idx} className="flex flex-wrap md:flex-nowrap items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100 group">
                    <div className="relative w-12 h-12 bg-white rounded-lg border border-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                      {item.thumbnail ? (
                        <img src={item.thumbnail} alt={item.name} className="w-full h-full object-cover" />
                      ) : (
                        <ImageIcon size={20} className="text-slate-300" />
                      )}
                      <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (ev) => {
                                const base64 = ev.target?.result as string;
                                const newDetails = [...(formData.productDetails || [])];
                                newDetails[idx].thumbnail = base64;
                                setFormData(prev => ({ ...prev, productDetails: newDetails }));
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                        <Plus size={16} className="text-white" />
                      </label>
                    </div>
                    <input 
                      type="text" 
                      placeholder={t('productName')}
                      value={item.name || ''}
                      onChange={(e) => {
                        const newDetails = [...(formData.productDetails || [])];
                        newDetails[idx].name = e.target.value;
                        setFormData(prev => ({ ...prev, productDetails: newDetails }));
                      }}
                      className="flex-1 min-w-[150px] px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 text-sm"
                    />
                    <div className="flex items-center gap-2">
                      <div className="flex flex-col">
                        <span className="text-[10px] text-slate-400 font-bold uppercase px-1">{t('quantity')}</span>
                        <div className="flex items-center bg-white border border-slate-200 rounded-lg overflow-hidden">
                          <button 
                            type="button"
                            onClick={() => {
                              const newDetails = [...(formData.productDetails || [])];
                              const currentQty = Number(newDetails[idx].quantity) || 1;
                              if (currentQty > 1) {
                                newDetails[idx].quantity = currentQty - 1;
                                // Sync price
                                const unitPrice = Number(newDetails[idx].unitPrice) || (Number(newDetails[idx].price) / currentQty) || 0;
                                newDetails[idx].unitPrice = unitPrice;
                                newDetails[idx].price = unitPrice * newDetails[idx].quantity;
                                setFormData(prev => ({ ...prev, productDetails: newDetails }));
                              }
                            }}
                            className="p-1 px-2 hover:bg-slate-50 text-slate-500 border-r border-slate-100"
                          >
                            <ChevronDown size={14} />
                          </button>
                          <input 
                            type="number"
                            value={item.quantity || 1}
                            onChange={(e) => {
                              const newDetails = [...(formData.productDetails || [])];
                              const newQty = Math.max(1, Number(e.target.value));
                              newDetails[idx].quantity = newQty;
                              // Sync price
                              const unitPrice = Number(newDetails[idx].unitPrice) || (Number(newDetails[idx].price) / (Number(item.quantity) || 1)) || 0;
                              newDetails[idx].unitPrice = unitPrice;
                              newDetails[idx].price = unitPrice * newQty;
                              setFormData(prev => ({ ...prev, productDetails: newDetails }));
                            }}
                            className="w-12 py-1.5 bg-transparent focus:outline-none text-center text-sm [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          />
                          <button 
                            type="button"
                            onClick={() => {
                              const newDetails = [...(formData.productDetails || [])];
                              const currentQty = Number(newDetails[idx].quantity) || 1;
                              newDetails[idx].quantity = currentQty + 1;
                              // Sync price
                              const unitPrice = Number(newDetails[idx].unitPrice) || (Number(newDetails[idx].price) / currentQty) || 0;
                              newDetails[idx].unitPrice = unitPrice;
                              newDetails[idx].price = unitPrice * newDetails[idx].quantity;
                              setFormData(prev => ({ ...prev, productDetails: newDetails }));
                            }}
                            className="p-1 px-2 hover:bg-slate-50 text-slate-500 border-l border-slate-100"
                          >
                            <ChevronUp size={14} />
                          </button>
                        </div>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] text-slate-400 font-bold uppercase px-1">{t('price')}</span>
                        <input 
                          type="number"
                          value={item.price || 0}
                          onChange={(e) => {
                            const newDetails = [...(formData.productDetails || [])];
                            const newPrice = Number(e.target.value);
                            newDetails[idx].price = newPrice;
                            // Update unit price based on manual price edit
                            const qty = Number(newDetails[idx].quantity) || 1;
                            newDetails[idx].unitPrice = newPrice / qty;
                            setFormData(prev => ({ ...prev, productDetails: newDetails }));
                          }}
                          className="w-24 px-2 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 text-sm"
                        />
                      </div>
                    </div>
                    <button 
                      type="button"
                      onClick={() => {
                        const newDetails = (formData.productDetails || []).filter((_, i) => i !== idx);
                        setFormData(prev => ({ ...prev, productDetails: newDetails }));
                      }}
                      className="text-rose-500 hover:bg-rose-50 p-2 rounded-lg transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
                <button 
                  type="button"
                  onClick={() => {
                    setFormData(prev => ({ 
                      ...prev, 
                      productDetails: [...(prev.productDetails || []), { name: '', price: 0, quantity: 1, unitPrice: 0 }] 
                    }));
                  }}
                  className="w-full py-2 border-2 border-dashed border-slate-300 rounded-xl text-slate-500 hover:border-amarous-teal hover:text-amarous-teal transition-all flex items-center justify-center gap-2 font-medium"
                >
                  <Plus size={18} />
                  {t('addItem')}
                </button>
              </div>
            </div>

            {/* Financial Summary Breakdown */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-3">
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">{t('productDetails')}</h4>
              
              {!formData.isPaid && (
                <div className="flex justify-center py-1 bg-rose-50 rounded-lg mb-2">
                  <span className="text-[10px] font-bold text-rose-600 uppercase tracking-widest">{t('paymentPending')}</span>
                </div>
              )}

              <div className="flex justify-between text-sm">
                <span className="text-slate-500">{t('subtotal')}</span>
                <span className="font-medium text-slate-800">{(Number(formData.total) || 0) - (Number(formData.shippingCost) || 0)} EGP</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">{t('shipping')}</span>
                <span className="font-medium text-slate-800">{Number(formData.shippingCost) || 0} EGP</span>
              </div>

              {Number(formData.discount) > 0 && (
                <div className="flex justify-between text-sm text-rose-600">
                  <span>
                    {t('discount')} 
                    {formData.discountType === 'percentage' ? ` (${formData.discount}%)` : ''}
                  </span>
                  <span>
                    -
                    {formData.discountType === 'percentage' 
                      ? (((Array.isArray(formData.productDetails) ? formData.productDetails : []).reduce((sum, item) => sum + (Number(item.price) || 0), 0) * (Number(formData.discount) || 0)) / 100).toFixed(2)
                      : (Number(formData.discount) || 0)
                    } EGP
                  </span>
                </div>
              )}

              <div className="h-px bg-slate-200 my-2"></div>

              <div className="flex justify-between text-base font-bold">
                <span className="text-slate-900">{t('total')}</span>
                <span className="text-slate-900">{Number(formData.total) || 0} EGP</span>
              </div>

              <div className="flex justify-between text-sm text-emerald-600 font-medium">
                <span>{t('paidAmount')}</span>
                <span>{Number(formData.paidAmount) || 0} EGP</span>
              </div>

              <div className="flex justify-between text-lg font-black text-amarous-teal pt-2 border-t border-amarous-teal/20">
                <span>{t('balance')}</span>
                <span>{(Number(formData.total) || 0) - (Number(formData.paidAmount) || 0)} EGP</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('customerPhone')}</label>
                <input 
                  type="text" 
                  name="customerPhone"
                  dir="ltr"
                  value={formData.customerPhone}
                  onChange={handleChange}
                  className={`w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'ar' ? 'text-right' : 'text-left'}`}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t('location')}</label>
                <input 
                  type="text" 
                  name="deliveryLocation"
                  value={formData.deliveryLocation}
                  onChange={handleChange}
                  className={`w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'en' ? 'text-left' : ''}`}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4 bg-slate-50 rounded-xl border border-slate-100">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-3">{t('paymentStatus')}</label>
                <label className={`flex items-center gap-3 ${userRole === 'admin' ? 'cursor-pointer' : 'cursor-not-allowed opacity-50'}`}>
                  <div className="relative">
                    <input 
                      type="checkbox" 
                      name="isPaid"
                      checked={formData.isPaid}
                      onChange={handleChange}
                      disabled={userRole !== 'admin'}
                      className="sr-only peer"
                    />
                    <div className={`w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:${language === 'ar' ? 'translate-x-[-100%]' : 'translate-x-full'} ${language === 'ar' ? 'rtl:peer-checked:after:-translate-x-5' : ''} peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:${language === 'ar' ? 'right-[2px]' : 'left-[2px]'} after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500`}></div>
                  </div>
                  <span className="text-sm font-medium text-slate-700">{formData.isPaid ? t('paid') : t('unpaid')}</span>
                </label>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-3">{t('paymentMethod')}</label>
                <select 
                  name="paymentMethod"
                  value={formData.paymentMethod}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 ${language === 'en' ? 'text-left' : ''}`}
                >
                  <option value="Cash">{t('cash')}</option>
                  <option value="Visa">{t('visa')}</option>
                  <option value="InstaPay">{t('instapay')}</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-3">{t('contactStatus')}</label>
                <label className={`flex items-center gap-3 ${userRole === 'admin' ? 'cursor-pointer' : 'cursor-not-allowed opacity-50'}`}>
                  <div className="relative">
                    <input 
                      type="checkbox" 
                      name="isContacted"
                      checked={formData.isContacted}
                      onChange={handleChange}
                      disabled={userRole !== 'admin'}
                      className="sr-only peer"
                    />
                    <div className={`w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:${language === 'ar' ? 'translate-x-[-100%]' : 'translate-x-full'} ${language === 'ar' ? 'rtl:peer-checked:after:-translate-x-5' : ''} peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:${language === 'ar' ? 'right-[2px]' : 'left-[2px]'} after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500`}></div>
                  </div>
                  <span className="text-sm font-medium text-slate-700">{formData.isContacted ? t('contacted') : t('notContacted')}</span>
                </label>
              </div>
            </div>

            {/* Confirm Payment Upload */}
            {userRole === 'admin' && (
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-emerald-700 uppercase tracking-wider flex items-center gap-2">
                    <Camera size={18} />
                    {t('confirmPayment')}
                  </h4>
                  {formData.paymentConfirmationImage && (
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, paymentConfirmationImage: null }))}
                      className="text-rose-500 hover:text-rose-700 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                </div>
                
                {formData.paymentConfirmationImage ? (
                  <div className="relative aspect-video rounded-xl overflow-hidden border border-emerald-200 bg-white group">
                    <img src={formData.paymentConfirmationImage} alt="Payment Confirmation" className="w-full h-full object-contain" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <a 
                        href={formData.paymentConfirmationImage} 
                        download="payment-confirmation.png"
                        className="p-2 bg-white rounded-lg text-slate-700 hover:bg-slate-100 transition-colors"
                      >
                        <Download size={20} />
                      </a>
                    </div>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center w-full p-6 border-2 border-dashed border-emerald-200 rounded-2xl hover:border-emerald-400 hover:bg-emerald-100/50 transition-all cursor-pointer group">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <div className="p-3 bg-emerald-100 rounded-full text-emerald-500 group-hover:bg-emerald-200 transition-colors mb-3">
                        <Camera size={24} />
                      </div>
                      <p className="mb-2 text-sm text-emerald-600 font-bold">{t('confirmPayment')}</p>
                      <p className="text-xs text-emerald-400 uppercase tracking-widest">{t('clickToUploadImage')}</p>
                    </div>
                    <input type="file" className="hidden" accept="image/*" onChange={handlePaymentConfirmationUpload} />
                  </label>
                )}
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">{t('notes')}</label>
              <textarea 
                name="notes"
                rows={4}
                value={formData.notes}
                onChange={handleChange}
                className={`w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amarous-teal/50 resize-none ${language === 'en' ? 'text-left' : ''}`}
                placeholder={t('addNotesHere')}
              ></textarea>
            </div>
          </form>
        </div>

        <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
          <button 
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 text-slate-600 font-medium hover:bg-slate-200 rounded-xl transition-colors"
          >
            {t('cancel')}
          </button>
          <button 
            type="submit"
            form="order-form"
            disabled={isSaving}
            className={`px-8 py-2.5 text-white font-semibold rounded-xl transition-colors shadow-sm flex items-center gap-2 ${
              type === 'social' 
                ? 'bg-purple-600 hover:bg-purple-700' 
                : 'bg-amarous-teal hover:bg-amarous-teal-dark'
            } ${isSaving ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {isSaving ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                {t('saving...')}
              </>
            ) : t('saveInvoice')}
          </button>
        </div>
      </div>
    </div>
  );
}
